#!/usr/bin/env node

exports.ChromiumDriver = require('./build/lib/driver.js').ChromiumDriver;
